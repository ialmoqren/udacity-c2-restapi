"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.config = {
    "postgres": {
        "username": process.env.POSTGRES_USERNAME,
        "password": process.env.POSTGRES_PASSWORD,
        "database": process.env.POSTGRES_DATABASE,
        "host": process.env.POSTGRES_HOST,
        "dialect": "postgres"
    },
    "aws": {
        "aws_reigion": process.env.AWS_REGIION,
        "aws_profile": process.env.AWS_PROFILE,
        "aws_media_bucket": process.env.AWS_MEDIA_BUCKET
    }
};
//# sourceMappingURL=config.js.map